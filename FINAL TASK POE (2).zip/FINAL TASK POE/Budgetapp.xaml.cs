﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace BUDGETAPP
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : BUDGETAPP
    {
        public MainWindow()
        {

        }

        private void button_Click(object sender, RoutedEventArgs e)
        {
            
        }



        public void contentVis(object sender, RoutedEventArgs e)




        { 
        if(CC.SelectedItem == "Renting Prperty")

            MM1.Visibility = System.Windows.Visibility.Visible;
            PP.Visibility = System.Windows.Visibility.Visible;
            TD.Visibility = System.Windows.Visibility.Visible;
            EIP.Visibility = System.Windows.Visibility.Visible;
            IR.Visibility = System.Windows.Visibility.Visible;
        else if(CC.SelectedItem == "Buying Property")


        }
        
        
        public MainWindow()
        {
            
            InitializeComponent();
        }
        
    }
}
